shout_name = input("what is your name?")
print ("Your name is " + shout_name)