def name_list(list1, list2):
    big_name1 = [i for i in list1]
   
    big_name2 = [j for j in list2]
    
    if len(big_name1)> len(big_name2):
        print (list1)
    else: 
        print (list2)

big_name = name_list("amazed", "wow")

print (big_name)