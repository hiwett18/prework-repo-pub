names_list = ["bob","jimmy","max b", "bernie", "jordan", "future hendrix"]

odd_listA = names_list[-1:2] 
odd_listA = ["bob","jimmy","future hendrix"]

even_listB = names_list[2:5]

print ("List with odd-number letters is", odd_listA)
print ("list with even number letters is", even_listB)

even_listB = ["bmax b" if i == "max b" else i for i in even_listB]
even_listB = ["bordan" if i == "jordan" else i for i in even_listB]
print (even_listB)

odd_listA = ["boc" if i == "bob" else i for i in odd_listA]
odd_listA = ["jimmc" if i == "jimmy" else i for i in odd_listA]
odd_listA = ["future hendric" if i == "future hendrix" else i for i in odd_listA]
print (odd_listA)

for x in range(len(even_listB)):
    print (even_listB[x])
