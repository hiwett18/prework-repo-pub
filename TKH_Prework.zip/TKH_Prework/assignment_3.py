names_list = ["bob","jimmy","max b", "bernie", "jordan", "future hendrix"]

longest_name = '' 

for name in names_list:
 if len(name) > len (longest_name):
     longest = name
 else: 
    print (longest_name)
print (longest)