over_under_list = [1,45,32,21,5,17,43,93]

for num in over_under_list:
    print (num)
    if num > 25: 
        print ("over")
    else: 
        print ("under")